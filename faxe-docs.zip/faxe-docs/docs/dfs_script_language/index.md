# Introducing the DFS Script Language

Faxe uses a DSL called **dfs**.
Dfs is heavily influenced by InfluxData's TICKScript, in fact faxe started out as a clone of Kapacitor.

To get a basic understanding of dfs, you can therefore read [Introducing the TICKscript language](https://docs.influxdata.com/kapacitor/v1.5/tick/introduction/).

Some notable differencies between TICKScript and dfs include:

* dfs uses the `def` keyword for declarations
* for comments the `%` sign is used
* in dfs there are no top-level `stream` or `batch` nodes
* lambda expression use different functions
* regular expressions start and end with '?'

There is more, we will get to that ...

In general dfs is used to build up DAGs (Directed Acyclic Graph) of computing via a script language.

While reading [TICKscript syntax](https://docs.influxdata.com/kapacitor/v1.5/tick/syntax/) will help you get more understanding
of `dfs`, here is also were the differences between TICKScript and dfs start to get bigger (tough not so much in syntax, so reading is recommended).

So lets dive right in and override some details you just read about TICKScript:

Keywords
--------

Word   |    Usage
-------|---------
true | boolean true
false | boolean false
TRUE | boolean true
FALSE | boolean false
lambda: | used to denote lambda expression
def | starts a variable declaration



Operators
---------

Operator    | Usage
------------|------
+| addition operator
-|substraction operator
/|division operator
*|multiplication operator
AND | and
OR | or
< | less than
> | greater than
=< | less than or equal
<= | less than or equal
=> |  greater or equal
 >= | greater or equal
 == | equal
!= | Not equal
/= | Not equal
! | Logical Not

  
Variable declarations
---------------------

    def string = 'this is a string !'
    def text = <<< this is a text with some weird chars :// %& >>>
    def func = lambda: "value" / 3
    def meas = 4.44
    def func2 = lambda: int(meas / 13)
    def an_int = 32342
    def a_float = 2131.342
    
    % a chain can also be bound to a declaration
    def in1 =
        |mqtt_subscribe()
        .host('127.0.0.1')
        .topic('some/topic')
    % it can then be used like so
    in1
        |debug()
    
Duration literals
-----------------
Duration literals define a span of time. 

A duration literal is comprised of two parts: an integer and a duration unit. It is essentially an integer terminated by one or a pair of reserved characters, which represent a unit of time.

The following table presents the time units used in declaring duration types.

Unit | Meaning
-----|--------
ms|millisecond
s|second
m|minute
h|hour
d|day
w|week

#### Examples
    
    def span = 10s
    def frequency = 10m
    def short = 50ms