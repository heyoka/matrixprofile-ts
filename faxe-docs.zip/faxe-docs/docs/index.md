# Faxe

Flow based data-collector and time-centric data-processor.

## Commands

* `mkdocs new [dir-name]` - Create a new project.
* `mkdocs serve` - Start the live-reloading docs server.
* `mkdocs build` - Build the documentation site.
* `mkdocs help` - Print this help message.

## Project layout

    mkdocs.yml    # The configuration file.
    docs/
        index.md  # The documentation homepage.
        ...       # Other markdown pages, images and other files.
        
        
        esp_avg.erl
        esp_bottom.erl
        esp_count.erl
        esp_distinct.erl
        esp_elapsed.erl
        esp_first.erl
        esp_geometric_mean.erl
        esp_kurtosis.erl
        esp_last.erl
        esp_max.erl
        esp_mean.erl
        esp_median.erl
        esp_min.erl
        esp_percentile.erl
        esp_range.erl
        esp_skew.erl
        esp_stats_difference.erl
        esp_stats_dist_count.erl
        esp_stddev.erl
        esp_sum.erl
        esp_top.erl
        esp_variance.erl
