List of currently supported nodes
---------------------------------

* [stats](./nodes/stats.md)
* python



| params | | trash | | input types  |

