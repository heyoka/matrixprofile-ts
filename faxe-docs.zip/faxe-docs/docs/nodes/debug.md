The debug node
=====================

The debug node logs all incoming data with erlang's `lager` framework and emits it, without touching it.
Where the logs will be written, depends on the `lager` config.


Example
-------

    |debug()


Parameters
----------

Parameter     | Description | Default 
--------------|-------------|--------- 
 