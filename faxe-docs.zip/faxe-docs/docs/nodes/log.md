The log node
=====================

Log incoming data to a file in json format (line by line)

Example
-------
    
    |log()
    .file('topics.txt') 


Parameters
----------

Parameter     | Description | Default 
--------------|-------------|--------- 
file( `string` )| valid writeable filepath |
